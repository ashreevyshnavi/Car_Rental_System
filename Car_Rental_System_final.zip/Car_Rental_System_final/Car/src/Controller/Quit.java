package Controller;

import Model.Database;
import Model.Operation;
import Model.User;

import java.sql.SQLException;
import java.util.Scanner;

public class Quit implements Operation {
    @Override
    public void operation(Database database, Scanner s, User user) throws SQLException {
        System.out.println("Thanks for Visiting US!");
        s.close();
    }
}
