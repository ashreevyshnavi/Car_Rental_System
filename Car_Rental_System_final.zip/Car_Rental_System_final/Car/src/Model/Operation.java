package Model;
import java.sql.SQLException;
import java.util.Scanner;
import Model.Database;
import Model.User;


public interface Operation {
//    public void Operation(Database database, Scanner s,User user);

    void operation(Database database, Scanner s, User user) throws SQLException;

//    void operation(Database database, Scanners, User user);
}
