package Model;

import Controller.*;

import java.sql.SQLException;
import java.util.Scanner;

public class Client extends User{
    private Operation[] operations = new Operation[] {new ViewCars(), new RentCar(),new ReturnCar(),new ShowUserRents(2), new EditUserData(), new ChangePassword(), new Quit()};
    public Client() {
        super();
    }
    @Override

    public void showList(Database database, Scanner s) throws SQLException {

        System.out.println("\n1. View Cars");
        System.out.println("2 . Rent Car");
        System.out.println("3. Return Car");
        System.out.println("4. Show My Rents");
        System.out.println("5. Edit My Data");
        System.out.println("6. Change Password");
        System.out.println("7. Quit\n");

        int i=s.nextInt();
        if(i<1 || i>7){
            showList(database, s);
            return;
        }
        operations[i-1].operation(database, s, this);
        if(i!=7){
            showList(database, s);
        }

    }


}
